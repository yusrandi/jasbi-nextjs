-- AlterTable
ALTER TABLE `Product` MODIFY `description` TEXT NULL;
