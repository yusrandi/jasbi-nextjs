"use strict";
(() => {
var exports = {};
exports.id = 8132;
exports.ids = [8132];
exports.modules = {

/***/ 536:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProductUpdate),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9093);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var primereact_radiobutton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2948);
/* harmony import */ var primereact_radiobutton__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var primereact_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(333);
/* harmony import */ var primereact_toast__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(primereact_toast__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var primereact_fileupload__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9770);
/* harmony import */ var primereact_fileupload__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(primereact_fileupload__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var primereact_tag__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5083);
/* harmony import */ var primereact_tag__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(primereact_tag__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1088);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(primereact_button__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var primereact_inputnumber__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4502);
/* harmony import */ var primereact_inputnumber__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(primereact_inputnumber__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var primereact_utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4355);
/* harmony import */ var primereact_utils__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(primereact_utils__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6085);
/* harmony import */ var primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_11__);












const getStaticPaths = async (context)=>{
    const res = await fetch(`https://api.jasbiapp.site/api/product`);
    const data = await res.json();
    const paths = data.responsedata.map((product)=>{
        return {
            params: {
                productId: product.id.toString()
            }
        };
    });
    return {
        paths,
        fallback: false
    };
};
const getStaticProps = async (context)=>{
    const id = context.params.productId;
    const res = await fetch(`https://api.jasbiapp.site/api/product/${id}`);
    const data = await res.json();
    const product = data.responsedata;
    const resKategoris = await fetch(`https://api.jasbiapp.site/api/kategori`);
    const dataKategoris = await resKategoris.json();
    const kategoris = dataKategoris.responsedata;
    return {
        props: {
            product: product,
            kategoris: kategoris
        }
    };
};
function ProductUpdate({ product , kategoris  }) {
    const [totalSize, setTotalSize] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const fileUploadRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const [selectedFile, setSelectedFile] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const [newProduct, setNewProduct] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(product);
    const [submitted, setSubmitted] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const toast = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const onTemplateSelect = (e)=>{
        let _totalSize = totalSize;
        let files = e.files;
        Object.keys(files).forEach((key)=>{
            _totalSize += files[key].size || 0;
        });
        setTotalSize(_totalSize);
    };
    const onTemplateUpload = (e)=>{
        let _totalSize = 0;
        e.files.forEach((file)=>{
            _totalSize += file.size || 0;
        });
        setTotalSize(_totalSize);
        toast.current?.show({
            severity: "info",
            summary: "Success",
            detail: "File Uploaded"
        });
    };
    const onTemplateRemove = (file, callback)=>{
        setTotalSize(totalSize - file.size);
        callback();
    };
    const onTemplateClear = ()=>{
        setTotalSize(0);
    };
    const headerTemplate = (options)=>{
        const { className , chooseButton , uploadButton , cancelButton  } = options;
        const value = totalSize / 10000;
        // const formatedValue = fileUploadRef && fileUploadRef.current ? fileUploadRef.current.formatSize(totalSize) : '0 B';
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: className,
            style: {
                backgroundColor: "transparent",
                display: "flex",
                alignItems: "center"
            },
            children: [
                chooseButton,
                uploadButton,
                cancelButton,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex align-items-center gap-3 ml-auto",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            value,
                            " KB / 1 MB"
                        ]
                    })
                })
            ]
        });
    };
    const itemTemplate = (file, props)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex align-items-center flex-wrap",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex align-items-center",
                    style: {
                        width: "40%"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            alt: file.name,
                            role: "presentation",
                            src: file.objectURL,
                            width: 100
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex flex-column text-left ml-3",
                            children: [
                                file.name,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                    children: new Date().toLocaleDateString()
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_tag__WEBPACK_IMPORTED_MODULE_7__.Tag, {
                    value: props.formatSize,
                    severity: "warning",
                    className: "px-3 py-2"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_8__.Button, {
                    type: "button",
                    icon: "pi pi-times",
                    className: "p-button-outlined p-button-rounded p-button-danger ml-auto",
                    onClick: ()=>onTemplateRemove(file, props.onRemove)
                })
            ]
        });
    };
    const emptyTemplate = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex align-items-center flex-column",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "pi pi-image mt-3 p-5",
                    style: {
                        fontSize: "5em",
                        borderRadius: "50%",
                        backgroundColor: "var(--surface-b)",
                        color: "var(--surface-d)"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    style: {
                        fontSize: "1.2em",
                        color: "var(--text-color-secondary)"
                    },
                    className: "my-5",
                    children: "Drag and Drop Image Here"
                })
            ]
        });
    };
    const chooseOptions = {
        icon: "pi pi-fw pi-images",
        iconOnly: true,
        className: "custom-choose-btn p-button-rounded p-button-outlined"
    };
    const uploadOptions = {
        icon: "pi pi-fw pi-cloud-upload",
        iconOnly: true,
        className: "custom-upload-btn p-button-success p-button-rounded p-button-outlined"
    };
    const cancelOptions = {
        icon: "pi pi-fw pi-times",
        iconOnly: true,
        className: "custom-cancel-btn p-button-danger p-button-rounded p-button-outlined"
    };
    function ProductDialogFooter() {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex mt-3 ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_8__.Button, {
                    label: "Cancel",
                    icon: "pi pi-times",
                    text: true,
                    onClick: ()=>{}
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_8__.Button, {
                    label: "Save",
                    icon: "pi pi-check",
                    text: true,
                    onClick: handleSave
                })
            ]
        });
    }
    const onInputNumberChange = (e, name)=>{
        const val = e.value || 0;
        // let _product = { ...product };
        // _product[`${name}`] = val;
        setNewProduct({
            ...newProduct,
            price: val
        });
    };
    const onCategoryChange = (e)=>{
        // let _product = { ...product };
        // _product['category'] = e.value;
        setNewProduct({
            ...newProduct,
            kategoriId: e.value
        });
    };
    const invoiceUploadHandler = ({ files  })=>{
        const [file] = files;
        console.log({
            file
        });
        setSelectedFile(file);
        const fileReader = new FileReader();
        fileReader.onload = (e)=>{
        // console.log(e.target.result);
        };
        fileReader.readAsDataURL(file);
    };
    async function handleSave() {
        console.log({
            newProduct
        });
        console.log({
            selectedFile
        });
        setSubmitted(true);
        if (newProduct.kategoriId === 0) {
            toast.current?.show({
                severity: "error",
                summary: "Error",
                detail: "please select at least one category",
                life: 3000
            });
            return;
        }
        // if (!selectedFile) {
        //     toast.current?.show({ severity: 'error', summary: 'Error', detail: 'please select an image', life: 3000 });
        //     return
        // }
        try {
            let formData = new FormData();
            formData.append("id", product.id.toString());
            formData.append("myImage", selectedFile);
            formData.append("imageName", selectedFile ? selectedFile.name : product.image);
            formData.append("name", newProduct.name);
            formData.append("kategoriId", newProduct.kategoriId.toString());
            formData.append("price", newProduct.price.toString());
            formData.append("stock", newProduct.stock.toString());
            formData.append("unit", newProduct.unit);
            formData.append("description", newProduct.description);
            const response = await fetch(`/api/product`, {
                method: "POST",
                body: formData
            });
            console.log({
                response
            });
            if (response.status === 200) {
                router.replace("/product");
            }
        } catch (error) {
            console.log({
                error
            });
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            "Hello ",
            product.name,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid crud-demo",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col-12",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "card p-fluid",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_toast__WEBPACK_IMPORTED_MODULE_5__.Toast, {
                                    ref: toast
                                }),
                                product.image && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: `/product/${product.image}`,
                                    alt: product.image,
                                    width: "150",
                                    className: "mt-0 mx-auto mb-5 block"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "field",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            htmlFor: "name",
                                            children: "Name"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                            id: "name",
                                            defaultValue: newProduct.name,
                                            onChange: (e)=>setNewProduct({
                                                    ...newProduct,
                                                    name: e.target.value
                                                }),
                                            required: true,
                                            autoFocus: true,
                                            className: (0,primereact_utils__WEBPACK_IMPORTED_MODULE_10__.classNames)({
                                                "p-invalid": submitted && !newProduct.name
                                            })
                                        }),
                                        submitted && !newProduct.name && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                            className: "p-invalid text-red-600",
                                            children: "Name is required."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "field",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "mb-3",
                                            children: "Category"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "formgrid grid",
                                            children: kategoris.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "field-radiobutton col-6",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_4__.RadioButton, {
                                                            inputId: `category${index + 1}`,
                                                            name: item.name,
                                                            value: item.id,
                                                            onChange: onCategoryChange,
                                                            checked: newProduct.kategoriId === item.id
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            htmlFor: `category${index + 1}`,
                                                            children: item.name
                                                        })
                                                    ]
                                                }, index))
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "formgrid grid",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "field col",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "price",
                                                    children: "Price"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputnumber__WEBPACK_IMPORTED_MODULE_9__.InputNumber, {
                                                    id: "price",
                                                    value: newProduct.price,
                                                    onValueChange: (e)=>onInputNumberChange(e, "price"),
                                                    mode: "currency",
                                                    currency: "IDR",
                                                    locale: "id-ID"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "field col",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "quantity",
                                                    children: "Stock"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputnumber__WEBPACK_IMPORTED_MODULE_9__.InputNumber, {
                                                    id: "quantity",
                                                    value: newProduct.stock,
                                                    onChange: (e)=>setNewProduct({
                                                            ...newProduct,
                                                            stock: e.value
                                                        })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "field",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            htmlFor: "name",
                                            children: "Unit"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                            id: "unit",
                                            defaultValue: newProduct.unit,
                                            onChange: (e)=>setNewProduct({
                                                    ...newProduct,
                                                    unit: e.target.value
                                                })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "field",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            htmlFor: "description",
                                            children: "Description"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_11__.InputTextarea, {
                                            id: "description",
                                            defaultValue: newProduct.description,
                                            onChange: (e)=>setNewProduct({
                                                    ...newProduct,
                                                    description: e.target.value
                                                }),
                                            required: true,
                                            rows: 3,
                                            cols: 20
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            children: "Product picture"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_fileupload__WEBPACK_IMPORTED_MODULE_6__.FileUpload, {
                            mode: "basic",
                            name: "demo[]",
                            url: "/api/upload",
                            accept: "image/*",
                            maxFileSize: 1000000,
                            onUpload: invoiceUploadHandler
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ProductDialogFooter, {})
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1088:
/***/ ((module) => {

module.exports = require("primereact/button");

/***/ }),

/***/ 9770:
/***/ ((module) => {

module.exports = require("primereact/fileupload");

/***/ }),

/***/ 4502:
/***/ ((module) => {

module.exports = require("primereact/inputnumber");

/***/ }),

/***/ 9093:
/***/ ((module) => {

module.exports = require("primereact/inputtext");

/***/ }),

/***/ 6085:
/***/ ((module) => {

module.exports = require("primereact/inputtextarea");

/***/ }),

/***/ 2948:
/***/ ((module) => {

module.exports = require("primereact/radiobutton");

/***/ }),

/***/ 5083:
/***/ ((module) => {

module.exports = require("primereact/tag");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("primereact/toast");

/***/ }),

/***/ 4355:
/***/ ((module) => {

module.exports = require("primereact/utils");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(536));
module.exports = __webpack_exports__;

})();