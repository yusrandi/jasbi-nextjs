"use strict";
(() => {
var exports = {};
exports.id = 7007;
exports.ids = [7007];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 6799:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7096);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4883);


async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    switch(req.method){
        case "GET":
            break;
        case "POST":
            return await register(req, res);
            break;
        default:
            break;
    }
}
async function getUsers(req, res) {
    return res.status(200).json({
        "hello": "Hello World"
    });
}
async function register(req, res) {
    const body = req.body;
    const userExist = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* ["default"].user.findFirst */ .Z.user.findFirst({
        where: {
            email: body.email
        }
    });
    if (userExist) return res.status(201).json({
        responsecode: 0,
        responsemsg: "Email Telah Tersedia",
        responsedata: {}
    });
    const user = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* ["default"].user.create */ .Z.user.create({
        data: {
            name: body.name,
            address: body.address,
            phone: body.phone,
            email: body.email,
            role: body.role,
            password: await bcrypt__WEBPACK_IMPORTED_MODULE_0__.hash(body.password, 10)
        }
    });
    const { password , createdAt , updatedAt , ...result } = user;
    return res.status(201).json({
        responsecode: 1,
        responsemsg: "User Created",
        responsedata: result
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6799));
module.exports = __webpack_exports__;

})();