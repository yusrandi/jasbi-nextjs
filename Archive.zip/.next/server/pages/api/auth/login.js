"use strict";
(() => {
var exports = {};
exports.id = 3908;
exports.ids = [3908];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 666:
/***/ ((module) => {

module.exports = require("nextjs-cors");

/***/ }),

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 5703:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7096);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4883);
/* harmony import */ var nextjs_cors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(666);
/* harmony import */ var nextjs_cors__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nextjs_cors__WEBPACK_IMPORTED_MODULE_2__);



async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    await nextjs_cors__WEBPACK_IMPORTED_MODULE_2___default()(req, res, {
        // Options
        methods: [
            "POST"
        ],
        origin: "*",
        optionsSuccessStatus: 200
    });
    switch(req.method){
        case "GET":
            break;
        case "POST":
            return await login(req, res);
            break;
        default:
            break;
    }
}
async function login(req, res) {
    const body = req.body;
    console.log({
        body
    });
    const userExist = await _lib_prisma__WEBPACK_IMPORTED_MODULE_1__/* ["default"].user.findFirst */ .Z.user.findFirst({
        where: {
            email: body.email
        }
    });
    if (!userExist) return res.status(201).json({
        responsecode: 0,
        responsemsg: "User Tidak Terdaftar",
        responsedata: {}
    });
    if (userExist && await bcrypt__WEBPACK_IMPORTED_MODULE_0__.compare(body.password, userExist.password)) {
        const { password , createdAt , updatedAt , ...userWithoutPass } = userExist;
        return res.status(201).json({
            responsecode: 1,
            responsemsg: "Selamat Datang",
            responsedata: userWithoutPass
        });
    } else {
        return res.status(201).json({
            responsecode: 0,
            responsemsg: "Email atau password salah!",
            responsedata: {}
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5703));
module.exports = __webpack_exports__;

})();