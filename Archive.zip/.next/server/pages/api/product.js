"use strict";
(() => {
var exports = {};
exports.id = 2759;
exports.ids = [2759];
exports.modules = {

/***/ 2616:
/***/ ((module) => {

module.exports = require("formidable");

/***/ }),

/***/ 666:
/***/ ((module) => {

module.exports = require("nextjs-cors");

/***/ }),

/***/ 3292:
/***/ ((module) => {

module.exports = require("fs/promises");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 3665:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var formidable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2616);
/* harmony import */ var formidable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(formidable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var fs_promises__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3292);
/* harmony import */ var fs_promises__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(fs_promises__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4883);
/* harmony import */ var nextjs_cors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(666);
/* harmony import */ var nextjs_cors__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(nextjs_cors__WEBPACK_IMPORTED_MODULE_4__);





const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    await nextjs_cors__WEBPACK_IMPORTED_MODULE_4___default()(req, res, {
        // Options
        methods: [
            "GET"
        ],
        origin: "*",
        optionsSuccessStatus: 200
    });
    switch(req.method){
        case "GET":
            return await getData(req, res);
            break;
        case "POST":
            return await store(req, res);
            break;
        default:
            break;
    }
}
function readFile(req, saveLocally) {
    const options = {};
    if (saveLocally) {
        options.uploadDir = path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "/public/products");
        options.filename = (name, ext, path, form)=>{
            return path.originalFilename;
        };
    }
    options.maxFileSize = 4000 * 1024 * 1024;
    const form = formidable__WEBPACK_IMPORTED_MODULE_0___default()(options);
    return new Promise((resolve, reject)=>{
        form.parse(req, async (err, fields, files)=>{
            console.log({
                fields
            });
            // console.log({files});
            if (err) reject(err);
            resolve({
                fields,
                files
            });
            try {
                if (parseInt(fields.id.toString()) === 0) {
                    await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* ["default"].product.create */ .Z.product.create({
                        data: {
                            image: fields.imageName.toString(),
                            name: fields.name.toString(),
                            price: parseInt(fields.price.toString()),
                            stock: parseInt(fields.stock.toString()),
                            unit: fields.unit.toString(),
                            description: fields.description.toString(),
                            kategoriId: parseInt(fields.kategoriId.toString())
                        }
                    });
                } else {
                    await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* ["default"].product.update */ .Z.product.update({
                        where: {
                            id: parseInt(fields.id.toString())
                        },
                        data: {
                            image: fields.imageName.toString(),
                            name: fields.name.toString(),
                            price: parseInt(fields.price.toString()),
                            stock: parseInt(fields.stock.toString()),
                            unit: fields.unit.toString(),
                            description: fields.description.toString(),
                            kategoriId: parseInt(fields.kategoriId.toString())
                        }
                    });
                }
            } catch (error) {
                console.log({
                    error
                });
            }
        });
    });
}
async function getData(req, res) {
    try {
        const datas = await _lib_prisma__WEBPACK_IMPORTED_MODULE_3__/* ["default"].product.findMany */ .Z.product.findMany({
            select: {
                id: true,
                image: true,
                kategoriId: true,
                name: true,
                price: true,
                stock: true,
                unit: true,
                description: true,
                kategori: true
            },
            orderBy: [
                {
                    name: "asc"
                }
            ]
        });
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: datas
        });
    } catch (error) {
        console.log(error);
    }
}
async function store(req, res) {
    try {
        await fs_promises__WEBPACK_IMPORTED_MODULE_2___default().readdir(path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd() + "/public", "/products"));
    } catch (error) {
        await fs_promises__WEBPACK_IMPORTED_MODULE_2___default().mkdir(path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd() + "/public", "/products"));
    }
    console.log(req.body);
    try {
        await readFile(req, true);
        res.status(200).setHeader("Access-Control-Allow-Origin", "*").json({
            name: "Fake Upload Process"
        });
    } catch (error) {
        console.log(error);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3665));
module.exports = __webpack_exports__;

})();