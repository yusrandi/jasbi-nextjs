"use strict";
(() => {
var exports = {};
exports.id = 1369;
exports.ids = [1369];
exports.modules = {

/***/ 666:
/***/ ((module) => {

module.exports = require("nextjs-cors");

/***/ }),

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 5281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4883);
/* harmony import */ var nextjs_cors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(666);
/* harmony import */ var nextjs_cors__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nextjs_cors__WEBPACK_IMPORTED_MODULE_1__);


async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    await nextjs_cors__WEBPACK_IMPORTED_MODULE_1___default()(req, res, {
        // Options
        methods: [
            "GET",
            "POST"
        ],
        origin: "*",
        optionsSuccessStatus: 200
    });
    switch(req.method){
        case "GET":
            return await getData(req, res);
            break;
        case "POST":
            return await store(req, res);
            break;
        default:
            break;
    }
}
async function getData(req, res) {
    try {
        const datas = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].notifikasi.findMany */ .Z.notifikasi.findMany({
            select: {
                id: true,
                datetime: true,
                transaksi: {
                    select: {
                        id: true,
                        datetime: true,
                        transaksiCode: true,
                        customerId: true,
                        customer: true,
                        productId: true,
                        product: true,
                        qty: true,
                        total: true,
                        file: true,
                        status: true
                    }
                },
                transaksiId: true,
                status: true
            },
            orderBy: [
                {
                    datetime: "desc"
                }
            ]
        });
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: datas
        });
    } catch (error) {
        console.log(error);
    }
}
async function store(req, res) {
    const { name  } = req.body;
    try {
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].kategori.create */ .Z.kategori.create({
            data: {
                name: name
            }
        });
        const result = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].kategori.findMany */ .Z.kategori.findMany({
            select: {
                id: true,
                name: true
            }
        });
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: result
        });
    } catch (error) {
        console.log(error);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5281));
module.exports = __webpack_exports__;

})();