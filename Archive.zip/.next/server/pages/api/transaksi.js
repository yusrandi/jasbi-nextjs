"use strict";
(() => {
var exports = {};
exports.id = 5620;
exports.ids = [5620];
exports.modules = {

/***/ 2616:
/***/ ((module) => {

module.exports = require("formidable");

/***/ }),

/***/ 3292:
/***/ ((module) => {

module.exports = require("fs/promises");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 7421:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "formidable"
var external_formidable_ = __webpack_require__(2616);
var external_formidable_default = /*#__PURE__*/__webpack_require__.n(external_formidable_);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(1017);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
// EXTERNAL MODULE: external "fs/promises"
var promises_ = __webpack_require__(3292);
var promises_default = /*#__PURE__*/__webpack_require__.n(promises_);
// EXTERNAL MODULE: ./lib/prisma.ts + 1 modules
var prisma = __webpack_require__(4883);
;// CONCATENATED MODULE: ./utils/currentdatetime.ts
function CurrentDateTime() {
    var today = new Date();
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today.getFullYear();
    var hh = String(today.getHours()).padStart(2, "0");
    var ss = String(today.getMinutes()).padStart(2, "0");
    let todays = `${yyyy}/${mm}/${dd} ${hh}:${ss}`;
    return todays;
}

;// CONCATENATED MODULE: ./pages/api/transaksi/index.ts





const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    switch(req.method){
        case "GET":
            return await getData(req, res);
            break;
        case "POST":
            return await store(req, res);
            break;
        default:
            break;
    }
}
function readFile(req, res, saveLocally) {
    const options = {};
    if (saveLocally) {
        options.uploadDir = external_path_default().join(process.cwd(), "/public/transaksi");
        options.filename = (name, ext, path, form)=>{
            return path.originalFilename;
        };
    }
    options.maxFileSize = 4000 * 1024 * 1024;
    const form = external_formidable_default()(options);
    return new Promise((resolve, reject)=>{
        form.parse(req, async (err, fields, files)=>{
            console.log({
                fields
            });
            console.log({
                files
            });
            console.log({
                err
            });
            // console.log(fields.stock.toString());
            if (err) reject(err);
            let status = fields.status;
            try {
                if (parseInt(fields.id.toString()) === 0) {
                    const existingData = await prisma/* default.transaksi.findFirst */.Z.transaksi.findFirst({
                        select: {
                            id: true,
                            datetime: true,
                            transaksiCode: true,
                            customerId: true,
                            customer: true,
                            productId: true,
                            product: true,
                            qty: true,
                            total: true,
                            file: true,
                            status: true
                        },
                        where: {
                            status: status,
                            customerId: parseInt(fields.customerId.toString()),
                            productId: parseInt(fields.productId.toString())
                        }
                    });
                    if (existingData) {
                        return res.status(200).json({
                            responsecode: 0,
                            responsemsg: "Product Telah Dikeranjang",
                            responsedata: [
                                existingData
                            ]
                        });
                    }
                    const transaksi = await prisma/* default.transaksi.create */.Z.transaksi.create({
                        data: {
                            transaksiCode: createId(),
                            datetime: CurrentDateTime(),
                            file: fields.imageName.toString(),
                            status: status,
                            qty: parseInt(fields.qty.toString()),
                            total: parseInt(fields.total.toString()),
                            customerId: parseInt(fields.customerId.toString()),
                            productId: parseInt(fields.productId.toString())
                        }
                    });
                    console.log({
                        transaksi
                    });
                    await prisma/* default.notifikasi.create */.Z.notifikasi.create({
                        data: {
                            datetime: CurrentDateTime(),
                            transaksiId: transaksi.id,
                            status: status
                        }
                    });
                } else {
                    await prisma/* default.transaksi.update */.Z.transaksi.update({
                        where: {
                            id: parseInt(fields.id.toString())
                        },
                        data: {
                            datetime: CurrentDateTime(),
                            file: fields.imageName.toString(),
                            status: status,
                            qty: parseInt(fields.qty.toString()),
                            total: parseInt(fields.total.toString()),
                            customerId: parseInt(fields.customerId.toString()),
                            productId: parseInt(fields.productId.toString())
                        }
                    });
                    await prisma/* default.notifikasi.create */.Z.notifikasi.create({
                        data: {
                            datetime: CurrentDateTime(),
                            transaksiId: parseInt(fields.id.toString()),
                            status: status
                        }
                    });
                }
                resolve({
                    fields,
                    files
                });
            } catch (error) {
                console.log({
                    error
                });
            }
        });
    });
}
async function getData(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: CurrentDateTime() });
    try {
        const datas = await prisma/* default.transaksi.findMany */.Z.transaksi.findMany({
            select: {
                id: true,
                datetime: true,
                transaksiCode: true,
                customerId: true,
                customer: true,
                productId: true,
                product: true,
                qty: true,
                total: true,
                file: true,
                status: true
            },
            orderBy: [
                {
                    datetime: "desc"
                }
            ]
        });
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: datas
        });
    } catch (error) {
        console.log(error);
    }
}
async function store(req, res) {
    try {
        await promises_default().readdir(external_path_default().join(process.cwd() + "/public", "/transaksi"));
    } catch (error) {
        await promises_default().mkdir(external_path_default().join(process.cwd() + "/public", "/transaksi"));
    }
    try {
        await readFile(req, res, true);
        const datas = await prisma/* default.transaksi.findMany */.Z.transaksi.findMany({
            select: {
                id: true,
                datetime: true,
                transaksiCode: true,
                customerId: true,
                customer: true,
                productId: true,
                product: true,
                qty: true,
                total: true,
                file: true,
                status: true
            },
            orderBy: [
                {
                    datetime: "desc"
                }
            ]
        });
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: datas
        });
    } catch (error) {
        console.log(error);
    }
}
const createId = ()=>{
    let id = "";
    let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for(let i = 0; i < 10; i++){
        id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return id;
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7421));
module.exports = __webpack_exports__;

})();