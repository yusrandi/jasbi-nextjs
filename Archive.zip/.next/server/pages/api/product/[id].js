"use strict";
(() => {
var exports = {};
exports.id = 3021;
exports.ids = [3021];
exports.modules = {

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 8972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4883);

async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    switch(req.method){
        case "GET":
            return await getDataById(req, res);
            break;
        case "DELETE":
            return await deleteData(req, res);
            break;
        default:
            break;
    }
}
async function getDataById(req, res) {
    const { id  } = req.query;
    // return res.status(200).json(id)
    try {
        const result = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].product.findFirst */ .Z.product.findFirst({
            where: {
                id: {
                    equals: parseInt(id)
                }
            }
        });
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: result
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json(error);
    }
}
async function deleteData(req, res) {
    const { id  } = req.query;
    // return res.status(200).json(userId)
    try {
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].product["delete"] */ .Z.product["delete"]({
            where: {
                id: parseInt(id)
            }
        });
        const result = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].product.findMany */ .Z.product.findMany();
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: result
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json(error);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8972));
module.exports = __webpack_exports__;

})();