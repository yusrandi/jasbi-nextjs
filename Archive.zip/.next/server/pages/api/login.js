"use strict";
(() => {
var exports = {};
exports.id = 4994;
exports.ids = [4994];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 5946:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: external "bcrypt"
var external_bcrypt_ = __webpack_require__(7096);
// EXTERNAL MODULE: ./lib/prisma.ts + 1 modules
var prisma = __webpack_require__(4883);
;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_namespaceObject);
;// CONCATENATED MODULE: ./lib/jwt.ts

const DEFAULT_SIGN_OPTION = {
    expiresIn: "1h"
};
function signJwtAccesToken(payload, options = DEFAULT_SIGN_OPTION) {
    const secret_key = process.env.SECRET_KEY;
    const token = external_jsonwebtoken_default().sign(payload, secret_key, options);
    return token;
}
function verifyJwt(token) {
    try {
        const secret_key = process.env.SECRET_KEY;
        const decoded = jwt.verify(token, secret_key);
        return decoded;
    } catch (error) {
        console.log(error);
        return null;
    }
}

;// CONCATENATED MODULE: ./pages/api/login/index.ts



async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    switch(req.method){
        case "GET":
            break;
        case "POST":
            return await login(req, res);
            break;
        default:
            break;
    }
}
async function login(req, res) {
    const body = req.body;
    console.log(body);
    const user = await prisma/* default.user.findFirst */.Z.user.findFirst({
        where: {
            email: body.email
        }
    });
    console.log({
        user
    });
    if (user && await external_bcrypt_.compare(body.password, user.password)) {
        const { password , createdAt , updatedAt , ...userWithoutPass } = user;
        const accessToken = signJwtAccesToken(userWithoutPass);
        const result = {
            ...userWithoutPass,
            accessToken
        };
        res.status(201).json(result);
    // return new Response(JSON.stringify(result))
    } else res.status(201).json(null);
}
 // export async function POST(request:Request) {
 //     const body: RequestBody = await request.json();
 //     console.log(body);
 //     const user = await prisma.user.findFirst({
 //         where: {
 //             email: body.email
 //         }
 //     })
 //     console.log({user});
 //     if (user && (await bcrypt.compare(body.password, user.password!))){
 //         const {password,createdAt,updatedAt, ...userWithoutPass} = user
 //         const accessToken = signJwtAccesToken(userWithoutPass)
 //         const result = {
 //             ...userWithoutPass, accessToken
 //         }
 //         return new Response(JSON.stringify(result))
 //     }else return new Response(JSON.stringify(null))
 // }


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5946));
module.exports = __webpack_exports__;

})();