"use strict";
(() => {
var exports = {};
exports.id = 8653;
exports.ids = [8653];
exports.modules = {

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 3887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4883);

async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    switch(req.method){
        case "GET":
            return await getDataById(req, res);
            break;
        default:
            break;
    }
}
async function getDataById(req, res) {
    const { id  } = req.query;
    // return res.status(200).json(id)
    try {
        const result = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].notifikasi.findMany */ .Z.notifikasi.findMany({
            select: {
                id: true,
                datetime: true,
                status: true,
                transaksi: {
                    select: {
                        id: true,
                        datetime: true,
                        transaksiCode: true,
                        customerId: true,
                        customer: true,
                        productId: true,
                        product: true,
                        qty: true,
                        total: true,
                        file: true,
                        status: true
                    }
                }
            },
            where: {
                transaksi: {
                    customerId: parseInt(id)
                }
            },
            orderBy: {
                datetime: "desc"
            }
        });
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: result
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json(error);
    }
}
async function update(req, res) {
    const { name  } = req.body;
    const { id  } = req.query;
    try {
        const data = {
            name: name
        };
        await prisma.kategori.update({
            where: {
                id: parseInt(id)
            },
            data: data
        });
        const result = await prisma.kategori.findMany();
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: result
        });
    } catch (error) {
        return res.status(500).json(error);
    }
}
async function deleteData(req, res) {
    const { id  } = req.query;
    // return res.status(200).json(userId)
    try {
        await prisma.kategori.delete({
            where: {
                id: parseInt(id)
            }
        });
        const result = await prisma.kategori.findMany();
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: result
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json(error);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3887));
module.exports = __webpack_exports__;

})();