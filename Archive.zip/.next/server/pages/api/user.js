"use strict";
(() => {
var exports = {};
exports.id = 5541;
exports.ids = [5541];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 4883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ lib_prisma)
});

// UNUSED EXPORTS: prisma

;// CONCATENATED MODULE: external "prisma/prisma-client"
const prisma_client_namespaceObject = require("prisma/prisma-client");
;// CONCATENATED MODULE: ./lib/prisma.ts

const globalForPrisma = global;
const prisma = globalForPrisma.prisma || new prisma_client_namespaceObject.PrismaClient;
if (false) {}
/* harmony default export */ const lib_prisma = (prisma);


/***/ }),

/***/ 3800:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _lib_prisma__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4883);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7096);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_1__);


async function handler(req, res) {
    // res.status(200).setHeader('Access-Control-Allow-Origin', '*').json({ name: 'this is users api route' });
    switch(req.method){
        case "GET":
            return await getUsers(req, res);
            break;
        case "POST":
            return await store(req, res);
            break;
        default:
            break;
    }
}
async function getUsers(req, res) {
    try {
        const users = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.findMany */ .Z.user.findMany({
            select: {
                id: true,
                name: true,
                email: true,
                role: true,
                address: true,
                phone: true
            },
            orderBy: [
                {
                    role: "asc"
                }
            ]
        });
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Users found",
            responsedata: users
        });
    } catch (error) {
        console.log(error);
    }
}
async function store(req, res) {
    const { name , address , phone , email , password , role  } = req.body;
    try {
        const userExist = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.findFirst */ .Z.user.findFirst({
            where: {
                email: email
            }
        });
        if (userExist) return res.status(201).json({
            responsecode: 0,
            responsemsg: "Email Telah Tersedia",
            responsedata: {}
        });
        await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.create */ .Z.user.create({
            data: {
                name: name,
                address: address,
                phone: phone,
                email: email,
                password: await bcrypt__WEBPACK_IMPORTED_MODULE_1__.hash(password, 10),
                role: role
            }
        });
        const result = await _lib_prisma__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.findMany */ .Z.user.findMany();
        return res.status(200).json({
            responsecode: 1,
            responsemsg: "Data found",
            responsedata: result
        });
    } catch (error) {
        console.log(error);
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3800));
module.exports = __webpack_exports__;

})();