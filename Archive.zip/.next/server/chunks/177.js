"use strict";
exports.id = 177;
exports.ids = [177];
exports.modules = {

/***/ 177:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProductIndex),
/* harmony export */   "emptyProduct": () => (/* binding */ emptyProduct)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1088);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(primereact_button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var primereact_column__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8145);
/* harmony import */ var primereact_column__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(primereact_column__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var primereact_datatable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7447);
/* harmony import */ var primereact_datatable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(primereact_datatable__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var primereact_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2222);
/* harmony import */ var primereact_dialog__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(primereact_dialog__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var primereact_fileupload__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9770);
/* harmony import */ var primereact_fileupload__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(primereact_fileupload__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9093);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(primereact_inputtext__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var primereact_toast__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(333);
/* harmony import */ var primereact_toast__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(primereact_toast__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var primereact_toolbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(603);
/* harmony import */ var primereact_toolbar__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(primereact_toolbar__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9459);
/* eslint-disable @next/next/no-img-element */ 











const emptyProduct = {
    id: 0,
    name: "",
    image: "",
    description: "",
    price: 0,
    kategoriId: 0,
    stock: 0,
    unit: null,
    createdAt: null,
    updatedAt: null,
    kategori: null
};
function ProductIndex() {
    const [products, setProducts] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)([]);
    const [productDialog, setProductDialog] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false);
    const [deleteProductDialog, setDeleteProductDialog] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false);
    const [deleteProductsDialog, setDeleteProductsDialog] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false);
    const [product, setProduct] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(emptyProduct);
    const [selectedProducts, setSelectedProducts] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)([]);
    const [submitted, setSubmitted] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(false);
    const [globalFilter, setGlobalFilter] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("");
    const toast = (0,react__WEBPACK_IMPORTED_MODULE_10__.useRef)(null);
    const dt = (0,react__WEBPACK_IMPORTED_MODULE_10__.useRef)(null);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const [isLoading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        _services_product_service__WEBPACK_IMPORTED_MODULE_11__/* .ProductService.getData */ .M.getData().then((data)=>{
            console.log({
                data
            });
            setProducts(data.responsedata);
            setLoading(false);
        });
    }, []);
    const formatCurrency = (value)=>{
        return value.toLocaleString("id-ID", {
            style: "currency",
            currency: "IDR"
        });
    };
    const openNew = ()=>{
        router.push("/product/create");
        setProduct(emptyProduct);
        setSubmitted(false);
        setProductDialog(true);
    };
    const hideDialog = ()=>{
        setSubmitted(false);
        setProductDialog(false);
    };
    const hideDeleteProductDialog = ()=>{
        setDeleteProductDialog(false);
    };
    const hideDeleteProductsDialog = ()=>{
        setDeleteProductsDialog(false);
    };
    const saveProduct = ()=>{
        setSubmitted(true);
        if (product.name.trim()) {
            let _products = [
                ...products
            ];
            let _product = {
                ...product
            };
            setProducts(_products);
            setProductDialog(false);
            setProduct(emptyProduct);
        }
    };
    const editProduct = (product)=>{
        setProduct({
            ...product
        });
        router.push(`/product/update/${product.id}`);
    };
    const confirmDeleteProduct = (product)=>{
        setProduct(product);
        setDeleteProductDialog(true);
    };
    const deleteProduct = async ()=>{
        try {
            await _services_product_service__WEBPACK_IMPORTED_MODULE_11__/* .ProductService.deleteData */ .M.deleteData(product).then((data)=>{
                console.log({
                    data
                });
                if (data.responsecode === 1) {
                    setProducts(data.responsedata);
                    toast.current?.show({
                        severity: "success",
                        summary: "Successful",
                        detail: "Product Deleted",
                        life: 3000
                    });
                }
                setDeleteProductDialog(false);
                setProduct(emptyProduct);
                setLoading(false);
            });
        } catch (error) {
            console.log({
                error
            });
        }
    };
    const createId = ()=>{
        let id = "";
        let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for(let i = 0; i < 5; i++){
            id += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return id;
    };
    const exportCSV = ()=>{
        dt.current?.exportCSV();
    };
    const confirmDeleteSelected = ()=>{
        setDeleteProductsDialog(true);
    };
    const deleteSelectedProducts = ()=>{
        let _products = products.filter((val)=>!selectedProducts?.includes(val));
        setProducts(_products);
        setDeleteProductsDialog(false);
        setSelectedProducts([]);
        toast.current?.show({
            severity: "success",
            summary: "Successful",
            detail: "Products Deleted",
            life: 3000
        });
    };
    const leftToolbarTemplate = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_10___default().Fragment), {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "my-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        label: "New",
                        icon: "pi pi-plus",
                        severity: "success",
                        className: " mr-2",
                        onClick: openNew
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        label: "Delete",
                        icon: "pi pi-trash",
                        severity: "danger",
                        onClick: confirmDeleteSelected,
                        disabled: !selectedProducts || !selectedProducts.length
                    })
                ]
            })
        });
    };
    const rightToolbarTemplate = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_10___default().Fragment), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_fileupload__WEBPACK_IMPORTED_MODULE_6__.FileUpload, {
                    mode: "basic",
                    accept: "image/*",
                    maxFileSize: 1000000,
                    chooseLabel: "Import",
                    className: "mr-2 inline-block"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    label: "Export",
                    icon: "pi pi-upload",
                    severity: "help",
                    onClick: exportCSV
                })
            ]
        });
    };
    const nameBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "p-column-title",
                    children: "Name"
                }),
                rowData.name
            ]
        });
    };
    const stockBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "p-column-title",
                    children: "Stock"
                }),
                rowData.stock,
                " ",
                rowData.unit
            ]
        });
    };
    const imageBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "p-column-title",
                    children: "Image"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: `/products/${rowData.image}`,
                    alt: rowData.image,
                    className: "",
                    width: "100"
                })
            ]
        });
    };
    const priceBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "p-column-title",
                    children: "Price"
                }),
                formatCurrency(rowData.price)
            ]
        });
    };
    const categoryBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "p-column-title",
                    children: "Category"
                }),
                rowData.kategori?.name
            ]
        });
    };
    const actionBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    icon: "pi pi-pencil",
                    rounded: true,
                    severity: "success",
                    className: "mr-2",
                    onClick: ()=>editProduct(rowData)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                    icon: "pi pi-trash",
                    rounded: true,
                    severity: "warning",
                    onClick: ()=>confirmDeleteProduct(rowData)
                })
            ]
        });
    };
    const header = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-column md:flex-row md:justify-content-between md:align-items-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                className: "m-0",
                children: "Manage Products"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "block mt-2 md:mt-0 p-input-icon-left",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        className: "pi pi-search"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_7__.InputText, {
                        type: "search",
                        onInput: (e)=>setGlobalFilter(e.currentTarget.value),
                        placeholder: "Search..."
                    })
                ]
            })
        ]
    });
    const productDialogFooter = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                label: "Cancel",
                icon: "pi pi-times",
                text: true,
                onClick: hideDialog
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                label: "Save",
                icon: "pi pi-check",
                text: true,
                onClick: saveProduct
            })
        ]
    });
    const deleteProductDialogFooter = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                label: "No",
                icon: "pi pi-times",
                text: true,
                onClick: hideDeleteProductDialog
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                label: "Yes",
                icon: "pi pi-check",
                text: true,
                onClick: deleteProduct
            })
        ]
    });
    const deleteProductsDialogFooter = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                label: "No",
                icon: "pi pi-times",
                text: true,
                onClick: hideDeleteProductsDialog
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_2__.Button, {
                label: "Yes",
                icon: "pi pi-check",
                text: true,
                onClick: deleteSelectedProducts
            })
        ]
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "grid crud-demo",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "col-12",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "card",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_toast__WEBPACK_IMPORTED_MODULE_8__.Toast, {
                        ref: toast
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_toolbar__WEBPACK_IMPORTED_MODULE_9__.Toolbar, {
                        className: "mb-4",
                        left: leftToolbarTemplate,
                        right: rightToolbarTemplate
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_datatable__WEBPACK_IMPORTED_MODULE_4__.DataTable, {
                        ref: dt,
                        value: products,
                        selection: selectedProducts,
                        onSelectionChange: (e)=>setSelectedProducts(e.value),
                        dataKey: "id",
                        paginator: true,
                        rows: 10,
                        rowsPerPageOptions: [
                            5,
                            10,
                            25
                        ],
                        className: "datatable-responsive",
                        paginatorTemplate: "FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown",
                        currentPageReportTemplate: "Showing {first} to {last} of {totalRecords} products",
                        globalFilter: globalFilter,
                        emptyMessage: "No products found.",
                        header: header,
                        responsiveLayout: "scroll",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_3__.Column, {
                                selectionMode: "multiple",
                                headerStyle: {
                                    width: "4rem"
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_3__.Column, {
                                field: "category",
                                header: "Category",
                                sortable: true,
                                body: categoryBodyTemplate,
                                headerStyle: {
                                    minWidth: "10rem"
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_3__.Column, {
                                header: "Image",
                                body: imageBodyTemplate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_3__.Column, {
                                field: "name",
                                header: "Product Name",
                                sortable: true,
                                body: nameBodyTemplate,
                                headerStyle: {
                                    minWidth: "15rem"
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_3__.Column, {
                                field: "stock",
                                header: "Stock",
                                sortable: true,
                                body: stockBodyTemplate
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_3__.Column, {
                                field: "price",
                                header: "Price",
                                body: priceBodyTemplate,
                                sortable: true
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_3__.Column, {
                                body: actionBodyTemplate,
                                headerStyle: {
                                    minWidth: "10rem"
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dialog__WEBPACK_IMPORTED_MODULE_5__.Dialog, {
                        visible: deleteProductDialog,
                        style: {
                            width: "450px"
                        },
                        header: "Confirm",
                        modal: true,
                        footer: deleteProductDialogFooter,
                        onHide: hideDeleteProductDialog,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex align-items-center justify-content-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "pi pi-exclamation-triangle mr-3",
                                    style: {
                                        fontSize: "2rem"
                                    }
                                }),
                                product && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        "Are you sure you want to delete ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                            children: product.name
                                        }),
                                        "?"
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dialog__WEBPACK_IMPORTED_MODULE_5__.Dialog, {
                        visible: deleteProductsDialog,
                        style: {
                            width: "450px"
                        },
                        header: "Confirm",
                        modal: true,
                        footer: deleteProductsDialogFooter,
                        onHide: hideDeleteProductsDialog,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex align-items-center justify-content-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "pi pi-exclamation-triangle mr-3",
                                    style: {
                                        fontSize: "2rem"
                                    }
                                }),
                                product && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Are you sure you want to delete the selected products?"
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
}
 // export default ProductIndex;


/***/ }),

/***/ 9459:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ ProductService)
/* harmony export */ });
const ProductService = {
    async getData () {
        return await fetch("/api/product", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json());
    },
    async getDataById (id) {
        console.log({
            id
        });
        return await fetch(`/api/product/${id}`, {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json());
    },
    async deleteData (product) {
        return await fetch(`/api/product/${product.id}`, {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "DELETE"
        }).then((res)=>res.json());
    }
};


/***/ })

};
;