"use strict";
exports.id = 5328;
exports.ids = [5328];
exports.modules = {

/***/ 5328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ KategoriService)
/* harmony export */ });
const KategoriService = {
    async getData () {
        return await fetch("/api/kategori", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json());
    },
    async createData (kategori) {
        return await fetch("/api/kategori", {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "POST",
            body: JSON.stringify({
                name: kategori.name
            })
        }).then((res)=>res.json());
    },
    async updateData (kategori) {
        return await fetch(`/api/kategori/${kategori.id}`, {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "PUT",
            body: JSON.stringify({
                name: kategori.name
            })
        }).then((res)=>res.json());
    },
    async deleteData (kategori) {
        return await fetch(`/api/kategori/${kategori.id}`, {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "DELETE"
        }).then((res)=>res.json());
    }
};


/***/ })

};
;