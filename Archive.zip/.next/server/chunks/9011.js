"use strict";
exports.id = 9011;
exports.ids = [9011];
exports.modules = {

/***/ 9011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ UserService)
/* harmony export */ });
const UserService = {
    async getData () {
        return await fetch("/api/user", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json());
    },
    async createData (user, password) {
        return await fetch("/api/user", {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "POST",
            body: JSON.stringify({
                name: user.name,
                email: user.email,
                address: user.address,
                phone: user.phone,
                password: password,
                role: user.role
            })
        }).then((res)=>res.json());
    },
    async updateData (user, newPassword) {
        return await fetch(`/api/user/${user.id}`, {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "PUT",
            body: JSON.stringify({
                name: user.name,
                email: user.email,
                address: user.address,
                phone: user.phone,
                password: newPassword,
                role: user.role,
                oldPassword: user.password
            })
        }).then((res)=>res.json());
    },
    async deleteData (user) {
        return await fetch(`/api/user/${user.id}`, {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "DELETE"
        }).then((res)=>res.json());
    }
};


/***/ })

};
;