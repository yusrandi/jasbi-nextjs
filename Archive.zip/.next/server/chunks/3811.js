"use strict";
exports.id = 3811;
exports.ids = [3811];
exports.modules = {

/***/ 3811:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ TransaksiService)
/* harmony export */ });
const TransaksiService = {
    async getData () {
        return await fetch("/api/transaksi", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json());
    },
    // async createData(Transaksi: Transaksi) {
    //     return await fetch('/api/Transaksi',
    //         {
    //             headers: {
    //                 'Cache-Control': 'no-cache',
    //                 'Content-Type': 'application/json'
    //             },
    //             method: 'POST',
    //             body: JSON.stringify({
    //                 name: Transaksi.name,
    //             }),
    //         }
    //     )
    //         .then((res) => res.json());
    // },
    async updateData (transaksi) {
        return await fetch(`/api/transaksi`, {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "POST",
            body: JSON.stringify({
                id: transaksi.id,
                status: transaksi.status,
                imageName: transaksi.file,
                qty: transaksi.qty,
                total: transaksi.total,
                customerId: transaksi.customerId,
                productId: transaksi.productId
            })
        }).then((res)=>res.json());
    },
    async deleteData (transaksi) {
        return await fetch(`/api/transaksi/${transaksi.id}`, {
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json"
            },
            method: "DELETE"
        }).then((res)=>res.json());
    }
};


/***/ })

};
;