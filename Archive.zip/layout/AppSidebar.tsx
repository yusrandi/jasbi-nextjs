import { Page } from '../types/types';
import AppMenu from './AppMenu';

const AppSidebar: Page = () => {
    return <AppMenu />;
};

export default AppSidebar;
